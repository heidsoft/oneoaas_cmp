"""
Make `python -m pyvim` an alias for running `pyvim`.
"""
from __future__ import unicode_literals
from .entry_points.run_pyvim import run

run()
